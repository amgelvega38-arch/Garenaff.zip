# Conexión con el bot de Telegram (keys)

La app valida las keys creadas por el bot contra:
https://project--bc853c45-589d-41c2-b47a-6f12b0ac0b3b.lovable.app

- POST /api/public/activate  -> { key, device_id }
- POST /api/public/patches   -> { key, device_id } (catálogo vacío por ahora)

Respuestas de error: invalid_key, device_mismatch, expired.
BAN KEY borra la key (la app la rechaza en la siguiente validación). RESET KEY libera los dispositivos.
La URL es fija: al actualizar el ZIP NO cambies PantherAPIBaseURL en Info.plist y seguirá conectado.
Se quitó la key de prueba "123".
